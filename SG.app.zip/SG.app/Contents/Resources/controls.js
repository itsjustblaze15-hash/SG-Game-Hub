(() => {
  if (window.__sgInstalled) return;
  window.__sgInstalled = true;
  const post = value => window.webkit?.messageHandlers?.controls?.postMessage(value);
  // Retain a small local diagnostic so integration checks inspect actual trusted input and audio.
  const diagnostics = window.__sgDiagnostics = {keys:[], motion:0, errors:[], audio:[]};
  window.addEventListener('keydown', e => { diagnostics.keys.push({type:e.type,code:e.code,trusted:e.isTrusted,target:e.target?.tagName}); diagnostics.keys=diagnostics.keys.slice(-30); }, true);
  window.addEventListener('keyup', e => { diagnostics.keys.push({type:e.type,code:e.code,trusted:e.isTrusted,target:e.target?.tagName}); diagnostics.keys=diagnostics.keys.slice(-30); }, true);
  window.addEventListener('error', e => { diagnostics.errors.push(e.message); });
  const OriginalAudio = window.AudioContext;
  if (OriginalAudio) window.AudioContext = class extends OriginalAudio {
    constructor(...args) { super(...args); diagnostics.audio.push(this); }
  };
  let locked = null, pending = null;
  let pendingResolve = null, pendingReject = null;
  const supports = window.__sgSupportsCapture;
  const alive = window.__sgGameID === 'alive';
  const artificialPointer = 90421;
  if (alive) {
    for (const method of ['setPointerCapture','releasePointerCapture']) {
      const original = Element.prototype[method];
      Element.prototype[method] = function(id) { if (id !== artificialPointer) return original.call(this,id); };
    }
    const originalHas = Element.prototype.hasPointerCapture;
    Element.prototype.hasPointerCapture = function(id) { return id === artificialPointer || originalHas.call(this,id); };
    document.addEventListener('pointerdown', e => {
      if (e.isTrusted && e.target instanceof HTMLCanvasElement && !locked) e.target.requestPointerLock();
    }, true);
  }
  const editable = node => node instanceof Element && !!node.closest('input,textarea,select,[contenteditable="true"]');
  // Cancel WebKit's default typing action, which otherwise falls through to the
  // macOS alert sound. Keep the genuine event propagating to every game handler.
  window.addEventListener('keydown', event => {
    if (!editable(event.target) && !event.metaKey && !event.ctrlKey && !event.altKey) event.preventDefault();
  }, {capture:true,passive:false});
  document.addEventListener('focusin', e => post({action:'inputFocus',focused:editable(e.target)}), true);
  document.addEventListener('focusout', () => post({action:'inputFocus',focused:false}), true);
  if (supports) {
    // Expose the browser pointer-lock contract while macOS supplies relative motion.
    Object.defineProperty(document, 'pointerLockElement', {configurable:true, get:() => locked});
    Element.prototype.requestPointerLock = function() {
      if (!(this instanceof HTMLCanvasElement)) return Promise.reject(new Error('Choose the game canvas'));
      pending = this;
      if (locked === this) return Promise.resolve();
      return new Promise((resolve,reject) => { pendingResolve = resolve; pendingReject = reject; post({action:'captureMouse'}); });
    };
    document.exitPointerLock = () => post({action:'releaseMouse'});
  }
  window.sgMouseCaptureState = captured => {
    const previous = locked;
    locked = captured ? pending : null;
    if (!captured) pending = null;
    if (!captured && alive && previous) previous.dispatchEvent(new PointerEvent('pointerup',{pointerId:artificialPointer,bubbles:true}));
    document.documentElement?.classList.toggle('sg-mouse-captured', !!locked);
    if (previous !== locked) document.dispatchEvent(new Event('pointerlockchange'));
    if (captured) { pendingResolve?.(); pendingResolve = null; pendingReject = null; }
  };
  window.sgCaptureFailed = () => {
    pending = null;
    pendingReject?.(new Error('macOS could not capture the mouse'));
    pendingResolve = pendingReject = null;
    document.dispatchEvent(new Event('pointerlockerror'));
  };
  window.sgRelativeMotion = (dx, dy) => {
    if (!locked || !Number.isFinite(dx) || !Number.isFinite(dy)) return;
    diagnostics.motion++;
    diagnostics.lastMotion = {dx,dy};
    const movement = new MouseEvent('mousemove', {bubbles:true,clientX:innerWidth/2,clientY:innerHeight/2});
    // WebKit ignores movementX/movementY in MouseEventInit on some macOS versions.
    Object.defineProperties(movement, {movementX:{value:dx}, movementY:{value:dy}});
    locked.dispatchEvent(movement);
    if (alive) {
      locked.dispatchEvent(new PointerEvent('pointerdown',{pointerId:artificialPointer,button:0,clientX:innerWidth/2,clientY:innerHeight/2,bubbles:true}));
      locked.dispatchEvent(new PointerEvent('pointermove',{pointerId:artificialPointer,buttons:1,clientX:innerWidth/2+dx,clientY:innerHeight/2+dy,bubbles:true,cancelable:true}));
    }
  };
  document.addEventListener('keydown', event => {
    if (event.code === 'Escape') post({action:'releaseMouse'});
  }, true);
  document.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = 'html.sg-mouse-captured,html.sg-mouse-captured *{cursor:none!important}';
    document.head.appendChild(style);
    if (alive) {
      const text = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (text.nextNode()) text.currentNode.textContent = text.currentNode.textContent.replace('Drag to look', 'Mouse to look · Esc releases');
      for (const canvas of document.querySelectorAll('canvas[aria-label]')) canvas.setAttribute('aria-label', canvas.getAttribute('aria-label').replace('drag to look', 'click to capture mouse, move to look, Escape to release'));
    }
  }, {once:true});
  window.sgPrepareToLeave = () => {
    post({action:'releaseMouse'});
    window.dispatchEvent(new Event('blur'));
    window.dispatchEvent(new Event('beforeunload'));
    window.dispatchEvent(new PageTransitionEvent('pagehide', {persisted:true}));
    if (alive) fetch('/api/control', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'pause'})})
      .then(() => fetch('/api/control', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save'})})).catch(() => {});
  };
})();
